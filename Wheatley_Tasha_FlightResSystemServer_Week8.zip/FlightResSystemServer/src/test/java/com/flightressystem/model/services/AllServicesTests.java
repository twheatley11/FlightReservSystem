package com.flightressystem.model.services;

import org.junit.runner.RunWith;


import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ IAirlineSvcTest.class, IAvailableFlightsSvcTest.class, ICreditCardSvcTest.class, ICustomerLoginSvcTest.class, ICustomerSvcTest.class,
		IFlightSvcTest.class, ITravelItinerarySvcTest.class, ITravelReservationSvcTest.class})
public class AllServicesTests {

}
