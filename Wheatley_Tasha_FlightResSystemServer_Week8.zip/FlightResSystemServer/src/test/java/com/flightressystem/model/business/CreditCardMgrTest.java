package com.flightressystem.model.business;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.flightressystem.model.domain.CreditCard;
import com.flightressystem.model.exceptions.InvalidCreditCardException;
import com.flightressystem.model.exceptions.InvalidCustomerException;
import com.flightressystem.model.exceptions.ServiceLoadException;
import junit.framework.TestCase;

public class CreditCardMgrTest extends TestCase{
	
	
	// use a named logger instead of the root logger
	static private Logger logger = LogManager.getLogger("com.flightressystem");
	
	private CreditCardMgr ccmgr;
	private CreditCard creditCard; 
	//private String creditCardNum; 
	private Long id;

	@Before
	public void setUp() throws Exception {
		super.setUp();
		//ServicesFactory.getInstance(); 
	
		
		creditCard = new CreditCard();
		creditCard.setCreditCardType("visa");
		creditCard.setCreditCardNum("1234567890123456");
		creditCard.setCreditCardExp("0722");
		
		//creditCardNum = "1234567890123456";
		id = (long)1;
		
		ccmgr = new CreditCardMgr();
	}

	@Test
	public void testCreateCreditCardMgr() throws ServiceLoadException, InvalidCustomerException{
		try {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		CreditCardMgr creditCardMgr = (CreditCardMgr) context.getBean("creditCardMgr");
		assertTrue(Manager.class.isAssignableFrom(CreditCardMgr.class));
		assertTrue(creditCardMgr.create(creditCard));
		}
	catch (InvalidCreditCardException e1) {
		logger.error("CreditCardException");
		e1.printStackTrace();
		}
	catch (ServiceLoadException e2) {
		logger.error("ServiceLoadException");
		e2.printStackTrace();
		}
	catch (NullPointerException e3) {
		logger.error("NullPointerException when creating credit card object");
		e3.printStackTrace();
		}
	catch (Exception e4) {
		logger.error("Unexpected Exception Found");
		e4.printStackTrace();
	}
	finally {
		//finally block of code is where you put code that must run regardless if there is an exception
		logger.trace("Finally block");
		}
	}

	
	@Test
	public void testGetCreditCardMgr() throws ServiceLoadException, InvalidCustomerException{
		try {
		assertTrue(Manager.class.isAssignableFrom(CreditCardMgr.class));
		ccmgr.get(id);
		}
	catch (InvalidCreditCardException e1) {
		logger.error("CreditCardException");
		e1.printStackTrace();
		}
	catch (ServiceLoadException e2) {
		logger.error("ServiceLoadException");
		e2.printStackTrace();
		}
	catch (NullPointerException e3) {
		logger.error("NullPointerException when getting credit card object");
		e3.printStackTrace();
		}
	catch (Exception e4) {
		logger.error("Unexpected Exception Found");
		e4.printStackTrace();
	}
	finally {
		//finally block of code is where you put code that must run regardless if there is an exception
		logger.trace("Finally block");
		}
	}
	
	@Test
	public void testUpdateCreditCardMgr() throws ServiceLoadException, InvalidCustomerException{
		try {
		assertTrue(Manager.class.isAssignableFrom(CreditCardMgr.class));
		assertTrue(ccmgr.update(creditCard));
		}
	catch (InvalidCreditCardException e1) {
		logger.error("CreditCardException");
		e1.printStackTrace();
		}
	catch (ServiceLoadException e2) {
		logger.error("ServiceLoadException");
		e2.printStackTrace();
		}
	catch (NullPointerException e3) {
		logger.error("NullPointerException when updating credit card object");
		e3.printStackTrace();
		}
	catch (Exception e4) {
		logger.error("Unexpected Exception Found");
		e4.printStackTrace();
	}
	finally {
		//finally block of code is where you put code that must run regardless if there is an exception
		logger.trace("Finally block");
		}
	}

	@Test
	public void testDeleteCreditCardMgr() throws ServiceLoadException, InvalidCustomerException{
		try {
		assertTrue(Manager.class.isAssignableFrom(CreditCardMgr.class));
		assertTrue(ccmgr.delete(creditCard));
		}
	catch (InvalidCreditCardException e1) {
		logger.error("CreditCardException");
		e1.printStackTrace();
		}
	catch (ServiceLoadException e2) {
		logger.error("ServiceLoadException");
		e2.printStackTrace();
		}
	catch (NullPointerException e3) {
		logger.error("NullPointerException when deleting credit card object");
		e3.printStackTrace();
		}
	catch (Exception e4) {
		logger.error("Unexpected Exception Found");
		e4.printStackTrace();
	}
	finally {
		//finally block of code is where you put code that must run regardless if there is an exception
		logger.trace("Finally block");
		}
	}
}
