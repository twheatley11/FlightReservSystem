package com.fasterxml.jackson.databind;

public class JsonMappintException {

}
