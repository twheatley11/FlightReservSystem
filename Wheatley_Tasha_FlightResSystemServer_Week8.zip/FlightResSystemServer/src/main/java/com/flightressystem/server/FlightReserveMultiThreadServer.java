package com.flightressystem.server;

import java.net.ServerSocket;



import java.net.Socket;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FlightReserveMultiThreadServer {
	
	static private Logger logger = LogManager.getLogger("com.flightressystem");

	private static int threadsCreated=1;
	
	 /**
	  * keep the constructor private to prevent instantiation by outside callers.
	  */
			private FlightReserveMultiThreadServer() {
				// construct object . . .
			}
	
	@SuppressWarnings("resource")
	public static void startServer()
    {
     try
     {
    	      	  
    	  // loading via -D option
		  String propertyFileLocation = System.getProperty("prop_location");
      		
	    if (propertyFileLocation != null)
	    { 
	    	int PORT;
	      // Now that we have the property file location, lets have the load it up
	    	java.util.Properties props = new java.util.Properties();
			java.io.FileInputStream fis = new java.io.FileInputStream(propertyFileLocation);
			props.load(fis);
			fis.close();
			  
			PORT = Integer.parseInt(props.getProperty("port"));
			    		  
		    logger.info("FlightResSystem Server Started");

		    ServerSocket s = new ServerSocket(PORT); // port should come from a properties file
	       
		        for (;;)
		        {  
		        	Socket socket = s.accept( );
		        	
		        	@SuppressWarnings("resource")
					ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				    //@SuppressWarnings("unused")
					//CustomerMgr customerMgr = (CustomerMgr) context.getBean("customerMgr");
				    //CreditCardMgr creditCardMgr = (CreditCardMgr) context.getBean("creditCardMgr");
		        	
		        	FlightReserveMultiThreadServerHandler flightResSystemServerHandler = new FlightReserveMultiThreadServerHandler(socket, threadsCreated);
		        	flightResSystemServerHandler.run(context);
		        	
		        	logger.info("Threads created: " + threadsCreated);

					threadsCreated++;
		        }
			  
	    }
	    else
	    {
	      logger.error("Property file location not set. Passed in value is: " + propertyFileLocation + ".");
	    }       
     }
	catch (Exception e)
	{  logger.error("Issue starting Flight Reservation Server ", e);
	}    	  	
	
	} //end startServer

	public static void main(String[] args)
	{
		 FlightReserveMultiThreadServer.startServer();						
	}//end main
	
}
