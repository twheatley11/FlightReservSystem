package com.flightressystem.server;


import org.apache.logging.log4j.LogManager;


import org.apache.logging.log4j.Logger;

import com.flightressystem.model.business.CreditCardMgr;
import com.flightressystem.model.business.CustomerMgr;
import com.flightressystem.model.domain.CreditCard;
import com.flightressystem.model.domain.Customer;
import com.flightressystem.model.exceptions.InvalidCreditCardException;
import com.flightressystem.model.exceptions.InvalidCustomerException;
import com.flightressystem.model.exceptions.ServiceLoadException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import org.springframework.context.*;

public class FlightReserveMultiThreadServerHandler extends Thread {

	
	  private Socket incomingSocket; 
		private final int threadNumber;

		
	  static private Logger logger = LogManager.getLogger("com.flightressystem");
	  
			
			/**
				* overloaded ctor
				* 
				* @param _incomingSocket - from client
				*/
			public FlightReserveMultiThreadServerHandler(Socket _incomingSocket, int _threadNumber) 
			{
				 incomingSocket = _incomingSocket;
					threadNumber = _threadNumber;

			}

  /**
   * Extracts the objects from the Socket and invokes performAction method on it.
   * 
   * Writes back on the socket the updated RentalComposite object
   *
   */
  public void run (ApplicationContext context)
  {  
	  							
	  					ObjectInputStream in   = null;
						ObjectOutputStream out = null;

						try
							{
									in   = new ObjectInputStream(incomingSocket.getInputStream());
									out = new ObjectOutputStream(incomingSocket.getOutputStream());

									// retrieve the commandString
									String commandString = (String)in.readObject();
									
									logger.info("FlightResServerHandler::run:Received command to execute service: " + commandString);
																
									CustomerMgr customerMgr = (CustomerMgr) context.getBean("customerMgr");
								    CreditCardMgr creditCardMgr = (CreditCardMgr) context.getBean("creditCardMgr");

		      // Now as in the past, call the manager to perform action.
				if(commandString.equals("CreateCustomer")) {
					
					// retrieve object sent by Client over the ObjectInputStream
					Customer customer = (Customer)in.readObject();
					System.out.println(customer);
					
					//CustomerMgr custMgr = new CustomerMgr();
					
					
					//Customer customer1 = new Customer();
													
					try {
						//boolean status = custMgr.create(customer);
						boolean status = customerMgr.create(customer);
						//customer1 = custMgr.get(customer.getUserName());
						System.out.println("Account has been created");
						out.writeObject(status);
						out.writeObject(customer);
						out.flush();
						
					} catch (ServiceLoadException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (InvalidCustomerException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
					else if(commandString.equals("CreateCreditCard")) {		
						
						// retrieve object sent by Client over the ObjectInputStream
						CreditCard creditCard = (CreditCard)in.readObject();
						System.out.println(creditCard);
	
						//CreditCardMgr ccMgr = new CreditCardMgr();
					
						try {
							boolean status = creditCardMgr.create(creditCard);
							//customer1 = custMgr.get(customer.getUserName());
							System.out.println("Credit Card has been created");
							out.writeObject(status);
							out.writeObject(creditCard);
							out.flush();
							
						} catch (ServiceLoadException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (InvalidCreditCardException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				
					
							//flightResSystemServerManager.performAction(commandString, rentalComposite);

					//return modified object back to Client over the ObjectOutputStream										
				}
							}
				catch (Exception e)
			 {  
					 logger.error ("Error processing request from client", e);
				}
				finally
				{
							try {
									if (in != null) {
									in.close();
									}
									if (out != null) {
									out.close();
									}
									if (incomingSocket != null) {
									incomingSocket.close();
									}
							} catch (IOException e) {
								logger.error (e.getClass()+": "+ e.getMessage(), e);
							}
							logger.info (threadNumber + " exiting");
				}//end try/catch/finally
}//end run      
} // end class FleetRentalServerHandler



