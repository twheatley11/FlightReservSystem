package com.flightressystem.model.services.factory;

import java.util.List;

import lombok.Data;

@Data
public class ServicesPOJO {
	private List <ServicePOJO> services;
}
