package com.flightressystem.model.services.factory;

import lombok.Data;

@Data
public class ServicePOJO {

	private String interfaceName; 
	private String implementation;

}


