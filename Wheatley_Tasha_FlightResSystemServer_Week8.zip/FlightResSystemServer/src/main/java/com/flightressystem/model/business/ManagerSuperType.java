package com.flightressystem.model.business;

public class ManagerSuperType {

}
