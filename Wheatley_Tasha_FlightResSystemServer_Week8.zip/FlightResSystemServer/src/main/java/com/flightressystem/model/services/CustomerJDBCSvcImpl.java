package com.flightressystem.model.services;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.flightressystem.model.domain.Customer;
import com.flightressystem.model.exceptions.InvalidCustomerException;


public class CustomerJDBCSvcImpl implements ICustomerSvc{

		// TODO Auto-generated constructor stub
		
		// use a named logger instead of the root logger
		static private Logger logger = LogManager.getLogger("com.flightressystem");
		 
		

	@Override
	public void storeCustomer(Customer cust) throws InvalidCustomerException {
		// TODO Auto-generated method stub
		logger.info ("Entering Method CustomerSvcImpl: storeCustomer");
		try {
			if (!cust.getFirstName().matches("[a-zA-Z]+")) {
				throw new InvalidCustomerException( "Customer first name must be alphabetic");
			}
			else if (!cust.getLastName().matches("[a-zA-Z]+")) {
					throw new InvalidCustomerException( "Customer last name must be alphabetic");
				}
			else {
			String connString = "jdbc:mysql://localhost/regis?" + "user=root&password=admin";
			Connection conn = DriverManager.getConnection(connString);
			Statement stmt = conn.createStatement();
    	
    		    		
    		String sql = "INSERT INTO customers (lastName, firstName, userName, password, emailAddress, address, city, state, zipCode, custID) "
    				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    		PreparedStatement pstmt = conn.prepareStatement(sql);  
    		pstmt.setString(1, cust.getLastName()); 
    		pstmt.setString(2, cust.getFirstName());
    		pstmt.setString(3, cust.getUserName());  
    		pstmt.setString(4, cust.getPassword());  
    		pstmt.setString(5, cust.getEmailAddress());
    		pstmt.setString(6, cust.getAddress());  
    		pstmt.setString(7, cust.getCity());  
    		pstmt.setString(8, cust.getState());  
    		pstmt.setInt(9, cust.getZipCode());  
    		pstmt.setInt(10, cust.getCustID());  

       		pstmt.executeUpdate();
       		
       		
    		    		  		    		
    		stmt.close();
			conn.close();
			
			}
		} 
		catch (InvalidCustomerException e1) {
			logger.error("CustomerSvcImpl: storeCustomer - Invalid Account Exception", e1);
		}
		catch (NullPointerException e3) {
			logger.error("CustomerSvcImpl: storeCustomer - NullPointerException when reading customer object", e3);
			}
		catch(SQLException ex)	{
			
			throw new InvalidCustomerException("Could not perform DataPersistence Operation", ex);
    		// log the error (e.g., using Log4j)
		   	//System.out.println("SQLException: " + ex.getMessage());
		   // System.out.println("SQLState: " + ex.getSQLState());
		   // System.out.println("VendorError: " + ex.getErrorCode());
    	}
		finally {
			//finally block of code is where you put code that must run regardless if there is an exception
			logger.trace("Finally block");
			}
    	
	}

	@Override
	public Customer getCustomer(Long id) {
		logger.info ("Entering Method CustomerSvcImpl: getCustomer");
		Customer customer = new Customer();
		List<Customer> customers = new ArrayList<Customer>(); 
		try {
			String connString = "jdbc:mysql://localhost/regis?" + "user=root&password=admin";
			Connection conn = DriverManager.getConnection(connString);
			Statement stmt = conn.createStatement();
			ResultSet rs;
			
			rs = stmt.executeQuery("SELECT * FROM customers WHERE userName = username");
			while (rs.next()) {
				customer.setLastName(rs.getString("lastName"));
				customer.setFirstName(rs.getString("firstName"));
				customer.setUserName(rs.getString("userName"));
				customer.setPassword(rs.getString("password"));
				customer.setEmailAddress(rs.getString("emailAddress"));
				customer.setAddress(rs.getString("address"));
				customer.setCity(rs.getString("city"));
				customer.setState(rs.getString("state"));
				customer.setZipCode(rs.getInt("zipCode"));
				customer.setCustID(rs.getInt("custID"));
				
				customers.add(customer);
    			}
			
		}
		catch (NullPointerException e3) {
			logger.error("CustomerSvcImpl: storeCustomer - NullPointerException when reading customer object", e3);
			}
		catch(SQLException ex)	{
    		// log the error (e.g., using Log4j)
		   	logger.error("SQLException: " + ex.getMessage());
		    logger.info("SQLState: " + ex.getSQLState());
		   logger.error("VendorError: " + ex.getErrorCode());
    	}
		finally {
			//finally block of code is where you put code that must run regardless if there is an exception
			logger.trace("Finally block");
			}
		
		// TODO Auto-generated method stub
		return customer;
	}

}

