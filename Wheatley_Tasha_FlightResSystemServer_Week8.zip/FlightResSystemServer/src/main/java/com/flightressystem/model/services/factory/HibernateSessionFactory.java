package com.flightressystem.model.services.factory;


import org.apache.logging.log4j.LogManager;



import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

public class HibernateSessionFactory {


	static private Logger logger = LogManager.getRootLogger();
    

  
	//Holds a single instance of the session
    private static final ThreadLocal<Session> threadLocal = new ThreadLocal<Session>();
    
    
    /**
     * The single instance of hibernate SessionFactory
     */
    private static org.hibernate.SessionFactory sessionFactory;

    /**
     * @return Session
     * @throws HibernateException
     */
    public static Session currentSession() throws HibernateException {
        Session session = (Session) threadLocal.get();

        if (session == null || !session.isOpen()) {
            if (sessionFactory == null) {
                try {
                    sessionFactory = new Configuration()
                            .configure() // configures settings from hibernate.cfg.xml
                            .buildSessionFactory();

                } catch (Exception e) {
                    logger.error("%%%% Error Creating SessionFactory %%%%", e);
                }
            }
            session = (sessionFactory != null) ? sessionFactory.openSession() : null;
            threadLocal.set(session);
        }
        return session;
    }

    
    /**
     * Close the single hibernate session instance and
     * release the JDBC connection
     * 
     * @throws Hibernate Exception
     */
    public static void closeSession() throws HibernateException {
        Session session = (Session) threadLocal.get();
        
        threadLocal.set(null);

        if (session != null) {
            session.close();
        }
    }

    
  
    /**
     *  Used to call closeSessionAndFactory method to ensure that the session is closed
     * first and then closes the factory.  This will release all resources.
     * 
     * @throws HibernateException 
     */
    public static void closeFactory() throws HibernateException {
        closeSessionAndFactory();
    }
    
    
    /**
     * Closes the session and the factory.  
     * If this method is not called then the app will keep running. 
     * 
     * @throws HibernateException
     */
    public static void closeSessionAndFactory() throws HibernateException {
        Session session = (Session) threadLocal.get();
        threadLocal.set(null);

        if (session != null) {
            session.close();
        }

        if (sessionFactory != null) {
            sessionFactory.close();
            sessionFactory = null;
        }
    }

    /**
     * Default constructor.
     */
    private HibernateSessionFactory() {
    }
}
