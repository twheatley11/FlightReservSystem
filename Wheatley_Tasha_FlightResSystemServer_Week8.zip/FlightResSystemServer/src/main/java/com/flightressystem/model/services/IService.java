package com.flightressystem.model.services;


/**
 * @author Tasha Wheatley
 * @since 4/4/20
 * 
 * 
 * The Factory now requires that all services be requested by name and extend
 * the base interface IService
 */

public interface IService {


}
