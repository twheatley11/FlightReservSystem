package com.flightressystem.model.business;


public abstract class Manager {
	
	/*PRE SPRING APPROACH
	 * private ServicesFactory servicesFactory = ServicesFactory.getInstance();
	
	protected IService getService(String name) throws ServiceLoadException
	{
	 return servicesFactory.getService(name);
	}*/

}


