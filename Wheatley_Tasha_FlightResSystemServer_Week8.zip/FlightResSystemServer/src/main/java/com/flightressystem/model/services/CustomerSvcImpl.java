package com.flightressystem.model.services;

import org.hibernate.Session;



import org.hibernate.Transaction;

import com.flightressystem.model.domain.Customer;
import com.flightressystem.model.exceptions.InvalidCustomerException;
import com.flightressystem.model.services.factory.HibernateSessionFactory;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class CustomerSvcImpl implements ICustomerSvc{
	
	// use a named logger instead of the root logger
	static private Logger logger = LogManager.getLogger("com.flightressystem");

	public CustomerSvcImpl() {
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public void storeCustomer(Customer cust) throws InvalidCustomerException {
		logger.info ("Entering Method CustomerSvcImpl: storeCustomer");
		Transaction transaction = null;
	
		try {
			 logger.info("About to create a Hibernate Session");
	          Session session = HibernateSessionFactory.currentSession();
			if (!cust.getFirstName().matches("[a-zA-Z]+")) {
				throw new InvalidCustomerException( "Customer first name must be alphabetic");
			}
			else if (!cust.getLastName().matches("[a-zA-Z]+")) {
					throw new InvalidCustomerException( "Customer last name must be alphabetic");
				}
			else {
			
				//start the transaction
				transaction = session.beginTransaction();
	
				session.save(cust);

				transaction.commit();	
				
		        logger.info("Successfully Created " + cust.toString());
				}
		}
		catch (NullPointerException e1) {
			logger.error("CustomerSvcImpl: storeCustomer - NullPointerException when reading customer object", e1);
			}
		catch(InvalidCustomerException e2)	{
			logger.error("CustomerSvcImpl: storeCustomer - Invalid Account Exception", e2);
    	}
		catch(Exception e3) {
			if(transaction !=null) {
				transaction.rollback();
				}
			throw new InvalidCustomerException("Could not perform DataPersistence Operation", e3);
			}
		finally {
			//finally block of code is where you put code that must run regardless if there is an exception
			logger.trace("Finally block");
			HibernateSessionFactory.closeSession();
			}
		}
		

	@Override
	public Customer getCustomer(Long id) {
		// TODO Auto-generated method stub
		logger.info ("Entering Method CustomerSvcImpl: getCustomer");
		Transaction transaction = null;
		Customer customer = null;
		
		List<Customer> customers = new ArrayList<Customer>();
		try
		{
			Session session = HibernateSessionFactory.currentSession();
			//start the transaction
			transaction = session.beginTransaction();
			
			 // Get The Customer Details Whose id is 25
            customer = (Customer)session.get(Customer.class, id);
            if(customer != null) {
                System.out.println("\nEmployee Record?= " + customer.toString());
            }
            
			//customer = session.get(Customer.class, username);

			//System.out.println("username" + customer.getUserName());

			customers.add(customer);
			
			transaction.commit();			
		}
		
		catch(Exception e) {
			if(transaction !=null) {
				transaction.rollback();
			}		
		}
	     finally {
	        // close session only
	        HibernateSessionFactory.closeSession();
	        logger.info("Sucessfully closed session after saving data");
	    }
		return customer;
	}

}
